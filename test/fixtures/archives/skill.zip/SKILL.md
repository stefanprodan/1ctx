---
name: archive-fixture
description: A recorded archive skill.
---

# Archive fixture
Read references/guide.md.
